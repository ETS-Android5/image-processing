package com.university.ip.ui.viewer

import com.university.ip.ui.base.BasePresenter

class ViewerPresenter : BasePresenter<ViewerContract.View>(), ViewerContract.Presenter {

}