package com.university.ip.model

data class Photo(
    var path: String,
    var name: String
)